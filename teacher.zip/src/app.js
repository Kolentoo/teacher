import './styles/core.css';
import './styles/user.css';
import './styles/teacher.css';
import './scripts/core-ext.js';
import './scripts/teacher.js';
// import './scripts/jquery.lazyload.min.js';
import $ from './scripts/core-ext.js';

