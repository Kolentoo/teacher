$(function () {

    _IsIOS();

    $('body').show();
    var _scale = { width: 750, rem : true };

});

// 设备判断
function _IsIOS() {
    var ua = navigator.userAgent.toLowerCase();
    if (ua.match(/iPhone\sOS/i) == "iphone os") {
        $('body').children('div').addClass('pf').removeClass('sy');
        return true;
    } else {
        $('body').children('div').removeClass('pf').addClass('sy');
    }
}






















